<ul id="menu" class="page-sidebar-menu">
    @include('includes.menu')
</ul>
